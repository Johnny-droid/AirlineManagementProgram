#include <iostream>
#include "gtest/gtest.h"
#include "gmock/gmock.h"

int main(int argc, char* argv[]) {
    testing::InitGoogleTest(&argc, argv);
    std::cout << "AED 2021/2022 - Aula Pratica 4" << std::endl;
    return RUN_ALL_TESTS();
}


//     Macaco da Sorte
//          __
//     w  c(..)o   (
//      \__(-)    __)
//          /\   (
//         /(_)___)
//         w /|
//          | \
//         m  m
